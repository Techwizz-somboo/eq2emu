---
title: EQ2Emu FAQ
description: EQ2Emu Basic FAQ
published: true
date: 2025-09-04T12:51:25.087Z
tags: 
editor: markdown
dateCreated: 2025-05-31T23:21:07.647Z
---


# EQ2Emulator (EQ2Emu) FAQ
<div style="margin-top: 2em; padding: 1em; background-color: #f8f9fa; border-left: 4px solid #ffc107; font-size: 0.9em; line-height: 1.5;">
  <strong style="display: block; margin-bottom: 0.5em;">⚠️ Disclaimer</strong>
  <p style="margin: 0 0 0.5em 0;">
    <em>EverQuest II</em> and all associated names, logos, characters, and artwork are trademarks and/or copyrighted materials of Daybreak Game Company LLC.
    This project is a fan-made emulator designed for educational and preservation purposes. We are not affiliated with, endorsed by, or sponsored by Daybreak Game Company or any of its subsidiaries.
    All players are responsible for acquiring the game client legally through authorized sources such as Steam.
  </p>
  <p style="margin: 0;">
    EQ2Emu does not distribute or modify the official game client, nor does it accept donations or any form of payment.
    Use of this emulator is entirely voluntary and at the discretion of the end user.
  </p>
</div>

## What is EQ2Emu?
EQ2Emu is a fan-made server project that lets anyone run their own EverQuest II server. EQ2Emu primarily focuses on recreating the classic game (circa 2004–2005) with options to add or customize content. The project is open-source (GPLv3) and community-driven.

## How do I connect to play?
1. Choose a supported client (e.g. *Desert of Flames* or *Kingdom of Sky*).  See [How to Play](https://wiki.eq2emu.com/Guides/HowToPlay) for more information.
2. Edit the `eq2_default.ini` file in the client folder to include:
   ```
   cl_ls_address eq2emu.com
   ```
3. Run `EverQuest2.exe`, then log in with any username and password. If it’s a new account, it will be auto-created.

The [EQ2Emu wiki](https://wiki.eq2emu.com/Guides/HowToPlay) has full instructions.

## What game clients/eras are supported?

| Client                | Status                       |
|-----------------------|------------------------------|
| Desert of Flames Trial (Jan 2006)      | ✅ Recommended (Classic content) |
| Kingdom of Sky (Feb 2006)        | ✅ Supported                 |
| Altar of Malice (2015)       | ✅ Via Steam depot download  |
| Isle of Refuge (2005) | ⚠️ Beta support only, Boat & Isle Zones Only as Client does not include other files.        |

EQ2Emu focuses on Classic gameplay with some early expansion support.  See [How To Play](https://wiki.eq2emu.com/Guides/HowToPlay) for more information on the clients.

## How is EQ2Emu different from live EQII?
EQ2Emu runs older, community-maintained server code for EQ2 and primarily supports classic gameplay.  There is limited expansions or features supported post-2006. System requirements mirror those of the original client, and community contributions determine new features or content.

## What are the system requirements?
- **OS:** Windows 7 64-bit or newer
- **CPU:** Core 2 Duo / Athlon X2 or better
- **RAM:** 6GB or more
- **GPU:** DirectX 9-compatible

To **host a server**, a Linux machine with multiple cores and 8GB+ RAM is recommended.

## How do I create an account?
There is no registration page. Just launch the client, type in a new username/password combo, and the server will auto-create your account.

## What common technical issues should I check?
- Ensure `cl_ls_address` is set to `eq2emu.com` in `eq2_default.ini`.
- **AMD users**: Some older clients crash on AMD CPUs. A special DLL is available on the wiki to fix this, see the [Troubleshooting](https://wiki.eq2emu.com/Troubleshooting/EQ2Client) page.
- **Firewall/Antivirus**: May block client-server connection. Check exceptions.  Ports (Login Server) 9100 and (World Server) 9001 over UDP are required for EverQuest 2.  Servers may use custom ports that could change this requirement.

## Is EQ2Emu accepting donations or financial support?
**No. EQ2Emu is a fully self-funded fan project.** We do not accept any donations, payments, or monetary assistance of any kind.

Our goal is to preserve and emulate the classic EverQuest II experience for educational and archival purposes only. We are not affiliated with or endorsed by Daybreak Game Company or any of its subsidiaries. This project is strictly non-commercial and maintained by volunteers who fund the infrastructure and development themselves.

We believe in respecting the rights of the original developers and are committed to keeping EQ2Emu purely community-driven and free.

## How can I help or get involved?
EQ2Emu is open-source and welcomes contributions in:
- Code (GitHub)
- Quest scripting
- Bug testing
- Zone/NPC design

Join the [EQ2Emu Discord](https://discord.gg/ZAnsSZkf7v) or contribute via [GitHub](https://github.com/emagi/eq2emu).

---

# Historical Context

EverQuest II launched in November 2004. EQ2Emu development began shortly after in 2005.

## Original Class System (2004–2005)
- Players began as **Commoners**.
- Arriving at Isle of Refuge choose an **Archetype** from **Garven Tralk** (Fighter, Mage, Priest, Scout).
- At level 10: Chose a **Class** (e.g. Fighter becomes Brawlers, Crusaders, Warriors).
- At level 20: Chose a **Subclass** (e.g. Warriors becomes Berserker or Guardian).

## Post-KoS Class System (2006+)
With the **Kingdom of Sky** expansion (Live Update 19):
- The Commoner and class stages were removed.
- Players picked their final class at creation.

**EQ2Emu** focuses on the pre-KoS/classic structure but has partial support for newer systems.

---

# Contributors & Community Leads
Please note this table is a work in progress, many more contributors not included yet!!

| Name                  | Role(s)                                 | Notes |
|-----------------------|------------------------------------------|-------|
| **Edgar1898 (LethalEncounter)** | Former Lead Developer (2005 – 2011), Developer (2020 - 2021)              | Original EQ2Emu founder and core server coder. Former EQEmu developer. |
| **Cadimiom** (**Emagi/Image**)         | Developer (2005-2010), Developer (2020 - 2025)                               | Early + Current dev alongside Edgar1898.  Founder of EQ2Emu with LethalEncounter, former EQEmu founder. |
| **Acid1789**         | Developer (2005-2006)                               | <br/>Early Developer, original designer of the Packet Collector for EverQuest 2 and RC4 capture called "EverDump".  Later SOE Employee https://www.eqemulator.org/forums/showthread.php?p=133826 " The creator of EverDump (Acid1789) now works for SOE on EQ2 and he broke (fixed) the old method of getting the encryption key" |
| **John Adams**        | Administrator / Project Lead / Developer         | Forum and coordination support. |
| **Scribble** | Project Lead & Lua Scripts (2016) | Developed and maintained server-side Lua scripting frameworks for custom servers |
| **Cynnar** | Project Lead & Developer (2016 – 2024) | Took over project leadership in 2016 and has since driven core development, world-building content, and supportive tooling—including the Movement Loop Generator, collaborative community. |
| **Scatman**           | Developer / Community Contributor       | Involved in scripting and discussions. |
| **Jabantiz**          | Developer                               | Early code and technical contributions. |
| **Zcoretri** | Developer / PacketParser Developer (2009 – 2013) | Early Contributor to Core Server, PacketParser enhancements, struct updates |
| **Xinux**             | Developer                               | Likely contributor to database and server systems. |
| **theFoof** (**Smash**)           | Community & Dev Support                 | Developer, Tooling, Content Scripting. |
| **Techwizz** | Developer                       | Development, Documentation and Cross Platform Support. |
| **Oakshire (Dorbin)** | Content Developer                       | Authored dozens of quests/zones. Key member in classic content restoration. |
| **Devn00b**           | Project Manager / Developer / Quest Scripting (2020-2024)             | Authored Graystone scripts, classic NPC fixes. |
| **LordPazuzu**        | Current Lead Content, AI / Mob Balance                        | Tweaked combat AI and encounters. |
| **Neveruary**         | Raid/Encounter Scripting                | Focus on epic and scripted battles. |
| **Tyrbo** | Development Front End (2016) | Designed and implemented front-end features for the Stitch PvP server interface |
| **Ememjr**            | Perseverance Server Lead                | Built on EQ2Emu tech, classic zone restoration. |
| **Patrikpatrik** | Development Front End (2016) | UI and front-end enhancements for EQ2Emu server interfaces |
| **Sik San** | Content Development (2016) | Zone content creation, signage, and world-building contributions |
| **SAweb** | Core Stability Enhancements | Contributed critical world-server stability patches and feature backports. |
| **Diamente** | Performance Tuning | Optimized server loops and memory usage. |
| **Andrew** | Item & Spawn Handling | Enhanced item-loading code and improved spawn logic. |
| **paulgh** | Code Maintenance | Continued bug-fix backports and repository upkeep. |
| **Elcapototal** | “The Exterminator” | Known for aggressive memory-leak hunting and crash fixes. |
| **EmulateS** | Login & Security (Tommy_Six_Pack) | Hardened authentication paths and login-server robustness. |
| **Bion** | Parser Framework Creator | Originated the PacketParser framework and data-import tools. |
| **alfa** | Schema Localization Lead | Oversaw database schema translations. |
| **Riven** | Original DB Architect | Built the initial MySQL schema and migration scripts. |
| **chrrox** | Connector & Wrapper Author | Wrote the C++ "New" MySQL wrapper. |
| **Xanibunib** | Quest Designer | Authored numerous quest scripts and dialog handlers. |
| **JCL** | General Content Scripting | Contributed various world-event and NPC scripts. |
| **Nalandial** | Loot Table Developer | Designed advanced loot roll and distribution logic. |
| **Kinase77** | Event & Spawn Scripting | Built custom spawn triggers for world events. |
| **lnxmnky** | Packaging & Deployment | Managed Linux-based script packaging and distribution. |
| **shadowdeamon01** | NPC Behavior Scripting | Focused on complex NPC AI behaviors and pathing. |
| **l333** | Code Quality & Refactoring | Performed Lua code cleanups and refactors. |
| **Pesk** | Tier 3 Data Collector | Gathered high-detail packet and zone data sets. |
| **Benas** | Tier 1 Data Collector | Collected core packet definitions and simple data. |
| **Wdneq2** | Tier 2 Data Collector | Filled intermediate packet/schema sets. |
| **Arremis** | Tier 2 Data Collector | Assisted in zone and spell data imports. |
| **ilythor** | Community Manager | Moderated forums and coordinated community events. |
| **link2009** | Engagement Facilitator | Sparked community discussions and kept forums active. |
| **Aaden** | Forum Moderator | Assisted newcomers and enforced community guidelines. |
| **techguy84** | Technical Support | Provided installation and troubleshooting help. |
| **Enoex** | Wiki Editor | Maintained and updated the community knowledge base. |
| **CrabClaw** | Veteran Support | Offered deep-dive technical answers on forums. |
| **ZexisStryfe** | PM & Modeler | Provided project management, 3D models, and protocol insights. |
| **Rogean** | Web & Services Developer | Developed and maintained web services and API endpoints. |
| **Secrets** | Disassembler Specialist | Reverse-engineered client binaries and supplied packet documentation. |
| **bolly** | Wiki & Design Consultant | Contributed creative wiki layouts and UX improvements. |
| **aza77** | Early Code Tester | Performed foundational test cases on initial builds. |
| **ferthala** | Early Bug Reporter | Logged and tracked launch-phase issues. |
| **ritojo** | Community Evangelist | Spread word-of-mouth and brought in early testers. |
| **ichijin** | Documentation Helper | Assisted with early project documentation drafts. |
